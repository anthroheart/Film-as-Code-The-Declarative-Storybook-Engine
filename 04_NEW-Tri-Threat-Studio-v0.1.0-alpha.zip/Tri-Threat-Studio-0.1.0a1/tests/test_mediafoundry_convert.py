import tempfile
from pathlib import Path
from PIL import Image
import filecmp
import os
import subprocess
from mediafoundry import convert
import sys

MEDIAFOUNDRY_CLI = 'mediafoundry.cli'

def run_cli(args):
    cp = subprocess.run([sys.executable, '-m', MEDIAFOUNDRY_CLI] + args, capture_output=True, text=True)
    return cp.returncode, cp.stdout, cp.stderr

def test_lossless_image_copy_api():
    with tempfile.TemporaryDirectory() as td:
        orig = Path(td)/"in.png"
        out = Path(td)/"out.png"
        Image.new("RGB", (17, 11), color=(12,70,189)).save(orig)
        convert.convert_image_lossless(orig, out)
        # For PNG to PNG, filebytes should match (verify by filecmp)
        assert out.exists(), "Output not created"
        assert filecmp.cmp(orig, out, shallow=False), "PNG->PNG copy should be bytewise equal"

def test_lossless_image_copy_cli():
    with tempfile.TemporaryDirectory() as td:
        orig = Path(td)/"in.png"
        out = Path(td)/"out.png"
        Image.new("RGB", (3,4), color="lime").save(orig)
        code, outmsg, err = run_cli(["convert", str(orig), "--out", str(out)])
        assert code == 0
        assert "Image copied" in outmsg
        assert Path(out).exists(), "CLI: Output not created"
        assert filecmp.cmp(orig, out, shallow=False), "PNG->PNG CLI copy must be byte-identical"

def test_lossless_format_switch():
    with tempfile.TemporaryDirectory() as td:
        orig = Path(td)/"test.jpg"
        out = Path(td)/"test2.bmp"
        Image.new("RGB", (6,9), color=(5,4,3)).save(orig)
        convert.convert_image_lossless(orig, out)
        # Output visually same, not bytewise; pixel size/shape/format must match
        with Image.open(out) as newimg, Image.open(orig) as oldimg:
            assert newimg.size == oldimg.size
            assert newimg.mode == oldimg.mode
