import tempfile
import pathlib
import numpy as np
from PIL import Image
from framesteady.cli import analyze_sequence
from framesteady.validation import srgb_to_linear

def test_analyze_sequence_black_white_gray():
    with tempfile.TemporaryDirectory() as d:
        p_black = pathlib.Path(d)/"f000.png"
        p_white = pathlib.Path(d)/"f001.png"
        p_gray = pathlib.Path(d)/"f002.png"
        Image.fromarray(np.zeros((8,8,3), dtype=np.uint8)).save(p_black)
        Image.fromarray(np.full((8,8,3), 255, dtype=np.uint8)).save(p_white)
        Image.fromarray(np.full((8,8,3), 128, dtype=np.uint8)).save(p_gray)
        lums = analyze_sequence([p_black, p_white, p_gray])
        # Black: 0, White: ~1, Gray: ~0.2159 (linear sRGB)
        assert abs(lums[0]) < 1e-6
        assert 0.9 < lums[1] <= 1.0
        assert 0.20 < lums[2] < 0.23
