import tempfile
from pathlib import Path
from mediafoundry import metadata
from PIL import Image
import subprocess
import pytest

def test_get_image_metadata_basic():
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "im.png"
        img = Image.new("RGB", (17, 23), color="red")
        img.save(path)
        meta = metadata.get_image_metadata(path)
        assert meta['width'] == 17
        assert meta['height'] == 23
        assert meta['type'] == 'image'
        assert meta['format'] == 'PNG'

def test_get_image_metadata_error():
    with tempfile.TemporaryDirectory() as td:
        bad = Path(td) / "bad.png"
        bad.write_bytes(b"notanimage")
        meta = metadata.get_image_metadata(bad)
        assert meta is None

def test_get_video_metadata_stub():
    # Uses ffmpeg to make a stub video if available
    with tempfile.TemporaryDirectory() as td:
        vpath = str(Path(td) / "test.mp4")
        try:
            subprocess.check_output([
                "ffmpeg", "-f", "lavfi", "-i", "color=black:320x240", "-t", "1", "-pix_fmt", "yuv420p", vpath, "-y"
            ], stderr=subprocess.STDOUT)
        except Exception:
            pytest.skip("ffmpeg not available or failed to create test video")
        meta = metadata.get_video_metadata(vpath)
        assert meta is not None
        assert meta['type'] == 'video'
        assert meta['width'] == 320
        assert meta['height'] == 240
        assert float(meta['duration']) >= 0.9

def test_get_media_metadata_switch():
    with tempfile.TemporaryDirectory() as td:
        img = Path(td) / "x.bmp"
        im = Image.new("RGB", (2, 2)); im.save(img)
        assert metadata.get_media_metadata(img)['type'] == 'image'
        bogus = Path(td) / "file.xyz"
        bogus.write_text("n/a")
        assert metadata.get_media_metadata(bogus) is None
