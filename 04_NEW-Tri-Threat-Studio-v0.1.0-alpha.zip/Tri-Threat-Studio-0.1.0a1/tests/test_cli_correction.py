from pathlib import Path

import numpy as np
import pytest
from PIL import Image

from framesteady.cli import (
    correct_exposure_linear,
    save_corrected_sequence,
)
from framesteady.validation import srgb_to_linear, robust_luminance


def make_sequence(directory, values):
    directory.mkdir(parents=True, exist_ok=True)
    paths = []
    for index, value in enumerate(values):
        path = directory / f"frame{index:03}.png"
        Image.new("RGB", (8, 8), (value, value, value)).save(path)
        paths.append(path)
    return paths


def measure(path):
    with Image.open(path) as image:
        return robust_luminance(srgb_to_linear(np.array(image)))


def test_reachable_exposure_targets(tmp_path):
    # These required gains are inside the configured 0.25x..4x range.
    paths = make_sequence(tmp_path / "input", [96, 128, 160])
    report, target = save_corrected_sequence(paths, tmp_path / "out")

    assert len(report) == 3
    for record in report:
        assert not record["gain_limited"]
        # Around sRGB 128, half an 8-bit code value corresponds to about
        # 0.00182 in linear light. 0.002 allows that rounding error.
        assert abs(measure(record["output"]) - target) < 0.002


def test_large_exposure_difference_respects_gain_cap(tmp_path):
    paths = make_sequence(tmp_path / "input", [32, 128, 224])
    report, target = save_corrected_sequence(paths, tmp_path / "out")

    dark = report[0]
    assert dark["gain"] == pytest.approx(4.0)
    assert dark["gain_limited"] is True

    expected = measure(paths[0]) * 4.0
    actual = measure(dark["output"])
    # Near this output brightness, half a code is under 0.001 linear.
    assert actual == pytest.approx(expected, abs=0.001)
    assert actual < target  # Correct: matching would violate the gain cap.


def test_linear_gain_is_exact_before_encoding():
    image = np.full((4, 4, 3), 0.125, dtype=np.float32)
    corrected, gain = correct_exposure_linear(image, 0.25, 0.125)

    assert gain == pytest.approx(2.0)
    assert corrected.dtype == np.float32
    np.testing.assert_allclose(corrected, 0.25, atol=1e-7)


def test_static_sequence_preserves_pixels(tmp_path):
    paths = make_sequence(tmp_path / "input", [128, 128, 128])
    originals = {p: p.read_bytes() for p in paths}
    report, _ = save_corrected_sequence(paths, tmp_path / "out")

    for record in report:
        with Image.open(record["input"]) as before:
            with Image.open(record["output"]) as after:
                np.testing.assert_array_equal(
                    np.array(before), np.array(after)
                )

    assert all(p.read_bytes() == data for p, data in originals.items())


def test_black_stays_finite_and_black(tmp_path):
    paths = make_sequence(tmp_path / "input", [0, 0, 0])
    report, target = save_corrected_sequence(paths, tmp_path / "out")

    assert target == 0.0
    for record in report:
        assert record["gain"] == 1.0
        assert np.isfinite(record["post"])
        assert measure(record["output"]) == 0.0


def test_refuses_existing_outputs_before_writing(tmp_path):
    paths = make_sequence(tmp_path / "input", [96, 128])
    out = tmp_path / "out"
    out.mkdir()

    protected = out / "frame001_steady.png"
    protected.write_bytes(b"DO NOT OVERWRITE")

    with pytest.raises(FileExistsError):
        save_corrected_sequence(paths, out)

    assert protected.read_bytes() == b"DO NOT OVERWRITE"
    assert not (out / "frame000_steady.png").exists()


def test_accepts_string_paths(tmp_path):
    paths = make_sequence(tmp_path / "input", [128])
    report, _ = save_corrected_sequence(
        [str(p) for p in paths], str(tmp_path / "out")
    )
    assert Path(report[0]["output"]).is_file()


def test_rejects_duplicate_output_names(tmp_path):
    first = make_sequence(tmp_path / "first", [128])[0]
    second = make_sequence(tmp_path / "second", [128])[0]

    with pytest.raises(ValueError, match="duplicate"):
        save_corrected_sequence([first, second], tmp_path / "out")

    assert not (tmp_path / "out").exists()
