import pathlib
import tempfile
import shutil
from PIL import Image
import pytest
import numpy as np
from framesteady import validation
from framesteady.validation import srgb_to_linear, robust_luminance

def make_png(path, size=(8, 8), mode='RGB', color=(128, 128, 128)):
    img = Image.new(mode, size, color)
    img.save(path, format='PNG')

def test_natural_key_sort():
    filenames = ['frame10.png', 'frame2.png', 'frame1.png']
    sorted_files = sorted(filenames, key=validation.natural_key)
    assert sorted_files == ['frame1.png', 'frame2.png', 'frame10.png']

def test_validate_sequence_all_valid():
    with tempfile.TemporaryDirectory() as d:
        paths = []
        for i in range(3):
            p = pathlib.Path(d)/f"f{i:03}.png"
            make_png(p)
            paths.append(p)
        valid, size = validation.validate_png_sequence(paths)
        assert len(valid) == 3
        assert size == (8,8)

def test_validate_sequence_non_png():
    with tempfile.TemporaryDirectory() as d:
        png = pathlib.Path(d)/"frame001.png"
        jpg = pathlib.Path(d)/"frame002.jpg"
        make_png(png)
        Image.new('RGB', (8,8)).save(jpg, format='JPEG')
        with pytest.raises(ValueError):
            validation.validate_png_sequence([png, jpg])

def test_validate_sequence_mismatched_size():
    with tempfile.TemporaryDirectory() as d:
        p1 = pathlib.Path(d)/"a.png"
        p2 = pathlib.Path(d)/"b.png"
        make_png(p1, size=(8,8))
        make_png(p2, size=(9,9))
        with pytest.raises(ValueError):
            validation.validate_png_sequence([p1, p2])

def test_srgb_to_linear_gray_correctness():
    # Middle gray in sRGB (should be ~0.2159 in linear)
    img = np.full((2,2,3), 128, dtype=np.uint8)
    lin = srgb_to_linear(img)
    assert lin.shape == (2,2,3)
    target = 0.2159
    assert np.allclose(lin, target, atol=0.01)

def test_srgb_to_linear_black_white():
    img = np.zeros((1,1,3), dtype=np.uint8)
    lin = srgb_to_linear(img)
    assert np.allclose(lin, 0.0)
    img = np.full((1,1,3), 255, dtype=np.uint8)
    lin = srgb_to_linear(img)
    assert np.allclose(lin, 1.0)

def test_robust_luminance_ignore_black():
    # Compose an image: top half black, bottom half mid-gray (linearized from sRGB 128)
    img = np.zeros((8,8,3), dtype=np.uint8)
    img[4:,:,:] = 128
    lin = srgb_to_linear(img)
    lum = robust_luminance(lin, black_thresh=0.01, white_thresh=0.99)
    # Should return luminance of mid-gray (linearized 128 RGB)
    assert 0.20 < lum < 0.23

def test_robust_luminance_all_black():
    lin = np.zeros((4,4,3), dtype=np.float32)
    lum = robust_luminance(lin)
    assert lum == 0.0
