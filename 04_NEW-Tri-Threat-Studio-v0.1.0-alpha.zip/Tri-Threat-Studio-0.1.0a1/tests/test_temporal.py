import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image
import pytest

from framesteady.cli import exposure_targets, save_corrected_sequence


def test_smoothing_reduces_alternating_exposure():
    measurements = np.tile([0.1, 0.2], 30)
    targets = exposure_targets(measurements, window=7)
    before = np.std(np.log(measurements[7:-7]))
    after = np.std(np.log(targets[7:-7]))
    assert after < before * 0.2


def test_cut_prevents_cross_shot_smoothing():
    measurements = [0.1] * 8 + [0.4] * 8
    targets = exposure_targets(measurements, window=7, cuts=[8])
    np.testing.assert_allclose(targets, measurements, atol=1e-12)


def test_log_ramp_preserved_away_from_edges():
    measurements = np.exp(np.linspace(-3, -1, 31))
    targets = exposure_targets(measurements, window=5)
    np.testing.assert_allclose(
        targets[2:-2], measurements[2:-2], rtol=1e-12
    )


def test_black_shot_has_finite_zero_targets():
    targets = exposure_targets([0, 0, 0], window=15)
    np.testing.assert_array_equal(targets, [0, 0, 0])


@pytest.mark.parametrize("window", [0, 2, -3, 10003])
def test_invalid_window_rejected(window):
    with pytest.raises(ValueError):
        exposure_targets([0.1, 0.2], window=window)


@pytest.mark.parametrize("cuts", [[0], [3], [2, 1], [1, 1]])
def test_invalid_cuts_rejected(cuts):
    with pytest.raises(ValueError):
        exposure_targets([0.1, 0.2, 0.3], cuts=cuts)


def test_strength_zero_preserves_pixels_and_writes_reports(tmp_path):
    inputs = tmp_path / "inputs"
    inputs.mkdir()
    paths = []
    for i, value in enumerate([64, 128, 192]):
        path = inputs / f"frame{i}.png"
        Image.new("RGB", (8, 8), (value, value, value)).save(path)
        paths.append(path)

    output = tmp_path / "output"
    records, _ = save_corrected_sequence(
        paths, output, target="smooth", window=3, strength=0,
    )
    for record in records:
        assert record["gain"] == 1
        with Image.open(record["input"]) as before:
            with Image.open(record["output"]) as after:
                np.testing.assert_array_equal(
                    np.array(before), np.array(after)
                )

    data = json.loads((output / "report.json").read_text())
    assert data["frame_count"] == 3
    assert data["settings"]["target"] == "smooth"
    assert (output / "exposure.csv").is_file()


def test_cli_synthetic_sequence(tmp_path):
    inputs = tmp_path / "inputs"
    inputs.mkdir()
    for i, value in enumerate([96, 128, 96, 128, 96]):
        Image.new("RGB", (8, 8), (value, value, value)).save(
            inputs / f"frame{i}.png"
        )

    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    output = tmp_path / "output"
    result = subprocess.run(
        [
            sys.executable, "-m", "framesteady.cli",
            str(inputs), "--out", str(output), "--window", "3",
        ],
        capture_output=True, text=True, env=env, timeout=30,
    )

    assert result.returncode == 0, result.stderr
    assert len(list(output.glob("*.png"))) == 5
    data = json.loads((output / "report.json").read_text())
    assert data["settings"]["target"] == "smooth"
    assert all(np.isfinite(r["post"]) for r in data["frames"])
