import subprocess
import sys
import tempfile
import os
from pathlib import Path

MEDIAFOUNDRY_CLI = 'mediafoundry.cli'

def run_cli(args):
    # Returns (exit_code, stdout, stderr)
    cp = subprocess.run([sys.executable, '-m', MEDIAFOUNDRY_CLI] + args, capture_output=True, text=True)
    return cp.returncode, cp.stdout, cp.stderr

def test_scan_subcommand_help():
    code, out, err = run_cli(["scan", "--help"])
    assert code == 0
    assert "usage" in out.lower()
    assert "directory" in out
    assert "to scan for media files" in out

def test_scan_subcommand_stub_dir():
    with tempfile.TemporaryDirectory() as td:
        Path(f"{td}/a.png").touch()
        code, out, err = run_cli(["scan", td])
        assert code == 0
        assert "Found media files" in out
        assert "a.png" in out

def test_scan_subcommand_meta():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td)/"b.bmp"
        from PIL import Image
        Image.new("RGB", (21, 9)).save(p)
        code, out, err = run_cli(["scan", td, "--meta"])
        assert code == 0
        assert "b.bmp" in out
        assert "width=21" in out and "height=9" in out

def test_convert_subcommand_stub():
    code, out, err = run_cli(["convert", "stubinput.mp4"])
    assert code != 0
    assert ("unsupported image extension" in out.lower() or "error" in out.lower() or "unsupported image extension" in err.lower() or "error" in err.lower())

def test_unknown_command():
    code, out, err = run_cli(["nonexistentcmd"])
    assert code != 0 or ("usage" in out.lower() or "error" in out.lower())
