import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
from PIL import Image
import pytest

from texturesmith.core import (
    tile_edges, height_map, normal_map, roughness_map, generate,
)


def test_opposite_basecolor_edges_match():
    image = np.random.default_rng(4).random((32, 32, 3)).astype(np.float32)
    result = tile_edges(image)
    np.testing.assert_allclose(result[:, 0], result[:, -1], atol=1e-7)
    np.testing.assert_allclose(result[0], result[-1], atol=1e-7)


def test_constant_height_produces_flat_normals():
    result = normal_map(np.full((16, 16), 0.5, dtype=np.float32))
    np.testing.assert_allclose(result[..., 0], 0.5)
    np.testing.assert_allclose(result[..., 1], 0.5)
    np.testing.assert_allclose(result[..., 2], 1)


def test_normal_vectors_are_unit_length():
    height = np.random.default_rng(3).random((16, 16)).astype(np.float32)
    vectors = normal_map(height) * 2 - 1
    np.testing.assert_allclose(
        np.linalg.norm(vectors, axis=-1), 1, atol=1e-6
    )


def test_periodic_height_has_expected_normal_direction():
    x = np.arange(32) * (2 * np.pi / 32)
    height = np.tile(0.5 + 0.2 * np.sin(x), (32, 1)).astype(np.float32)
    normal = normal_map(height)
    assert normal[10, 0, 0] < 0.5
    assert normal[10, 16, 0] > 0.5
    np.testing.assert_allclose(normal[..., 1], 0.5, atol=1e-6)


def test_directx_flips_only_green():
    height = np.random.default_rng(7).random((16, 16)).astype(np.float32)
    gl = normal_map(height, convention="opengl")
    dx = normal_map(height, convention="directx")
    np.testing.assert_allclose(gl[..., 0], dx[..., 0])
    np.testing.assert_allclose(gl[..., 2], dx[..., 2])
    np.testing.assert_allclose(gl[..., 1], 1 - dx[..., 1], atol=1e-7)


def test_uniform_image_has_uniform_height_and_roughness():
    image = np.full((16, 16, 3), 0.5, dtype=np.float32)
    np.testing.assert_allclose(height_map(image), 0.5)
    roughness = roughness_map(image)
    assert np.all(np.isfinite(roughness))
    assert float(np.ptp(roughness)) < 1e-6


def test_export_is_reproducible_and_preserves_source(tmp_path):
    source = tmp_path / "surface.png"
    pixels = np.random.default_rng(9).integers(
        0, 256, (32, 32, 3), dtype=np.uint8
    )
    Image.fromarray(pixels).save(source)
    original = source.read_bytes()

    first, second = tmp_path / "first", tmp_path / "second"
    generate(source, first, size=32)
    generate(source, second, size=32)

    for name in [
        "source.png", "basecolor.png", "height.png",
        "normal.png", "roughness.png", "tiled-preview.png",
    ]:
        assert (first / name).read_bytes() == (second / name).read_bytes()

    assert source.read_bytes() == original
    data = json.loads((first / "settings.json").read_text())
    assert data["settings"]["size"] == 32

    with Image.open(first / "normal.png") as image:
        assert image.size == (32, 32)
        assert image.mode == "RGB"


def test_existing_directory_is_protected(tmp_path):
    output = tmp_path / "existing"
    output.mkdir()
    protected = output / "keep.txt"
    protected.write_text("KEEP")
    with pytest.raises(FileExistsError):
        generate(None, output, size=32)
    assert protected.read_text() == "KEEP"


def test_transparency_is_rejected(tmp_path):
    source = tmp_path / "transparent.png"
    Image.new("RGBA", (32, 32), (255, 0, 0, 0)).save(source)
    with pytest.raises(ValueError, match="Flatten"):
        generate(source, tmp_path / "out", size=32)


def test_demo_cli(tmp_path):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
    output = tmp_path / "demo"
    result = subprocess.run(
        [
            sys.executable, "-m", "texturesmith.cli",
            "--demo", "--size", "32", "--out", str(output),
        ],
        capture_output=True, text=True, env=env, timeout=30,
    )
    assert result.returncode == 0, result.stderr
    assert (output / "tiled-preview.png").is_file()
    assert (output / "settings.json").is_file()
