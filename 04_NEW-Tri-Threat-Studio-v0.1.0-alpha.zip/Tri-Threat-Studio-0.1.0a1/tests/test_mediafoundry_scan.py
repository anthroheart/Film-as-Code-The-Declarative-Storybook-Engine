import os
import tempfile
import shutil
import pathlib
import pytest
from mediafoundry import cli

def test_scan_media_files_basic():
    # Setup temp dir with files
    with tempfile.TemporaryDirectory() as d:
        media_files = ["file1.png", "file2.mp4", "sound.wav"]
        other_files = ["doc.txt", "script.py"]
        for fname in media_files + other_files:
            open(os.path.join(d, fname), "w").close()
        found = cli.scan_media_files(d)
        assert sorted(pathlib.Path(f).name for f in found) == sorted(media_files)

def test_scan_media_files_empty():
    with tempfile.TemporaryDirectory() as d:
        assert cli.scan_media_files(d) == []

def test_scan_media_files_nonexistent():
    with pytest.raises(ValueError):
        cli.scan_media_files("/nonexistent/dir/xyz")

