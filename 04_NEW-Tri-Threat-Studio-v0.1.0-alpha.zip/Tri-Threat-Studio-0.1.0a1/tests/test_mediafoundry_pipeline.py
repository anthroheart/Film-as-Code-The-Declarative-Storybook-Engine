import json
import shutil
import subprocess

import pytest

from mediafoundry.pipeline import process_file, probe
from mediafoundry.convert import convert_image_lossless
from PIL import Image


@pytest.fixture(scope="module")
def sample(tmp_path_factory):
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        pytest.skip("FFmpeg and ffprobe are required.")

    directory = tmp_path_factory.mktemp("sample")
    path = directory / "sample ; spaced name.mkv"

    # Procedural video and audio; no downloads or user media.
    result = subprocess.run(
        [
            "ffmpeg", "-nostdin", "-v", "error",
            "-f", "lavfi", "-i", "color=c=blue:s=320x240:r=12",
            "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
            "-t", "1", "-c:v", "ffv1", "-threads", "1",
            "-c:a", "pcm_s16le", str(path),
        ],
        capture_output=True, text=True, timeout=30,
    )
    assert result.returncode == 0, result.stderr
    return path


@pytest.mark.parametrize(
    "preset,extension", [
        ("proxy", ".mp4"), ("delivery", ".mp4"), ("audio", ".wav"),
    ]
)
def test_presets_end_to_end(sample, tmp_path, preset, extension):
    output = tmp_path / ("result" + extension)
    original = sample.read_bytes()
    report = process_file(sample, output, preset, timeout=30)

    assert report["success"] is True
    assert report["verification"]["full_decode_passed"] is True
    assert output.is_file()
    assert sample.read_bytes() == original

    saved = json.loads(
        output.with_name(output.name + ".json").read_text()
    )
    assert saved["success"] is True
    assert output.with_name(output.name + ".log").is_file()

    streams = probe(output)["streams"]
    if preset == "audio":
        assert [s["codec_type"] for s in streams] == ["audio"]
        assert streams[0]["codec_name"] == "pcm_s24le"
    else:
        video = next(s for s in streams if s["codec_type"] == "video")
        assert video["codec_name"] == "h264"
        assert video["width"] == 320
        assert video["height"] == 240
        assert any(s["codec_type"] == "audio" for s in streams)


def test_existing_output_untouched(sample, tmp_path):
    output = tmp_path / "existing.mp4"
    output.write_bytes(b"KEEP THIS")
    with pytest.raises(FileExistsError):
        process_file(sample, output)
    assert output.read_bytes() == b"KEEP THIS"


def test_corrupt_input_does_not_publish_video(tmp_path):
    source = tmp_path / "broken.mp4"
    source.write_bytes(b"not a video")
    output = tmp_path / "result.mp4"

    with pytest.raises(RuntimeError):
        process_file(source, output)

    assert not output.exists()
    report = json.loads((tmp_path / "result.mp4.json").read_text())
    assert report["success"] is False
    assert (tmp_path / "result.mp4.log").is_file()


def test_incorrect_extension_rejected(sample, tmp_path):
    with pytest.raises(ValueError):
        process_file(sample, tmp_path / "wrong.wav", preset="proxy")


def test_image_conversion_refuses_overwrite(tmp_path):
    source = tmp_path / "source.png"
    output = tmp_path / "existing.png"
    Image.new("RGB", (8, 8), "red").save(source)
    output.write_bytes(b"KEEP IMAGE")

    with pytest.raises(FileExistsError):
        convert_image_lossless(source, output)
    assert output.read_bytes() == b"KEEP IMAGE"
