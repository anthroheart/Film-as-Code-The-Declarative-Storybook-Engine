#!/bin/sh
set -eu
cd "$(dirname "$0")"

if [ "${1:-}" = "--test" ]; then
    set -- python -m pytest -q \
        tests/test_validation.py \
        tests/test_cli_analysis.py \
        tests/test_cli_correction.py \
        tests/test_temporal.py
else
    set -- python -m framesteady.cli "$@"
fi

exec docker run --rm \
    --network none \
    --read-only \
    --cap-drop ALL \
    --security-opt no-new-privileges \
    --pids-limit 128 \
    --memory 2g \
    --cpus 2 \
    --user "$(id -u):$(id -g)" \
    --tmpfs /tmp:rw,nosuid,nodev,size=256m,mode=1777 \
    --mount "type=bind,src=$PWD,dst=/workspace" \
    --workdir /workspace \
    --env PYTHONPATH=/workspace/src \
    tri-threat-sandbox:local "$@"
