# Tri-Threat Studio

Three local Python tools. No subscriptions, accounts, or API keys required.

**Version 0.1.0a1 — experimental community release.**

Original code is MIT licensed. Created by AnthroHeart and contributors.
These are focused utilities, not complete commercial-software replacements.
Use copies of important media. Feedback and pull requests are welcome.

## Included tools

- FrameSteady: global exposure deflickering for PNG frame sequences.
- MediaFoundry: video proxies, delivery MP4s, and audio extraction.
- TextureSmith: tileable texture candidates and approximate material maps.

## Install with Python

Requires Python 3.11 or newer. From this folder:

    python3 -m venv .venv
    source .venv/bin/activate
    python -m pip install --upgrade pip
    python -m pip install .

On Windows, activate with .venv\Scripts\Activate.ps1 in PowerShell.
Use python instead of python3 where appropriate.

Installed commands: framesteady, mediafoundry, texturesmith.

MediaFoundry video/audio processing also requires ffmpeg and ffprobe on PATH.
Its MP4 presets require libx264 and, when audio is present, AAC encoding.

Development was tested in Linux Docker. Windows and macOS have not been
verified. Dependency versions are not pinned.

## Alternative: Docker on Linux

Install and start Docker, then build:

    docker build -t tri-threat-sandbox:local .

Enable the launchers:

    chmod +x run_*.sh

Use ./run_framesteady.sh, ./run_mediafoundry.sh, or ./run_texturesmith.sh
instead of the installed Python command names in the examples below.

The launchers mount this folder only. Put copies of your media inside it and
use relative paths. Do not place secrets or irreplaceable files here.

Image building downloads dependencies. Processing runs without network access.
The shell launchers use Linux UID/GID conventions.

## FrameSteady

Example:

    framesteady input-frames --out corrected-frames --window 15

Use consecutive frames of the SAME scene, not unrelated pictures.
Inputs are same-size RGB PNGs, assumed to be 8-bit sRGB, naturally sorted.

The tool measures brightness in linear light, smooths log exposure, and adjusts
each frame's exposure. It does not blend neighboring images.

Options:
- --window 15: odd-numbered smoothing window in frames.
- --strength 0.5: half correction strength in exposure-stop terms.
- --max-stops 2: limit gains to 0.25x through 4x.
- --cuts 100,250: new shots start at these zero-based sorted-frame indices.
- --target median: constant median normalization instead of temporal smoothing.

Outputs: corrected PNGs, exposure.csv, and report.json.
Use a fresh output folder; existing output files are refused.

Limitations:
- Global exposure only, not local flicker or rolling-band removal.
- Changing subjects and intentional lighting changes can confuse measurement.
- Short sequences and shot edges have limited temporal context.
- Clipped highlights cannot be recovered.
- No HDR/color-managed input, video import/export, or reference regions yet.
- Interrupted processing can leave completed frames or partial reports.

## MediaFoundry

Examples:

    mediafoundry presets
    mediafoundry process video.mp4 --preset proxy --out proxy.mp4
    mediafoundry process video.mp4 --preset delivery --out delivery.mp4
    mediafoundry process video.mp4 --preset audio --out extracted.wav

Presets:
- proxy: H.264 MP4 within 1280x720 without upscaling.
- delivery: H.264 MP4 at approximately original dimensions.
- audio: first audio stream decoded to 24-bit PCM WAV.

Video presets select the first ordinary video stream and first audio stream,
if present. Other streams are reported as discarded. Metadata and chapters
are not copied.

Outputs have companion .json reports and .log files. An empty log is normal
when FFmpeg reports no warnings or errors.

The tool checks output streams and duration where available, then decodes the
entire output to detect decoding errors.

A video without an audio track cannot produce extracted audio.
WAV extraction does not improve the source's actual audio quality.

Additional commands:

    mediafoundry scan media-folder --meta
    mediafoundry convert picture.png --out picture-copy.png

Only same-extension byte copying is guaranteed lossless. Image format
conversion may lose metadata, precision, transparency, or quality.

Limitations:
- SDR, square-pixel video is the intended input.
- Known HDR transfer tags are rejected; untagged HDR is not reliably detected.
- No HDR tone mapping or managed color-space conversion.
- No watch folders, queues, loudness normalization, or custom JSON presets yet.
- Proxy size and editing performance depend on source and editor.
- Existing output artifacts are refused.
- Failed processing can leave diagnostic sidecars, but not published failed video.
- Choose a fresh name when retrying after a failure.
- Publication requires same-filesystem hard-link support.
- Media, report, and log are not one atomic transaction.
- --timeout applies separately to encoding and verification.

## TextureSmith

Built-in demo:

    texturesmith --demo --out texture-demo

Photograph:

    texturesmith stone.jpg --out stone-material --size 1024

Use surface photographs such as stone, wood, fabric, or dirt.
Input is center-cropped to a square. Open tiled-preview.png first.

Outputs:
- source.png: cropped/resized input before edge blending.
- basecolor.png: edge-blended texture candidate.
- height.png: approximate height.
- normal.png: tangent-space normals.
- roughness.png: approximate roughness; brighter means rougher.
- tiled-preview.png: repeating 3x3 preview.
- settings.json: settings and limitations.

Controls:
- --blend 0.15
- --height-contrast 1.5
- --height-blur 1
- --invert-height
- --normal-strength 4
- --normal-convention opengl
- --roughness-base 0.6
- --roughness-detail 0.3

In Blender, import base color as sRGB and the other maps as Non-Color.
Connect the normal texture through a Normal Map node.
OpenGL is the default normal convention; DirectX flips green.

Limitations:
- These are artistic approximations, not recovered physical materials.
- Photo brightness is not necessarily height; base color is not measured albedo.
- Edge blending can produce ghosting and obvious repetition.
- Matching border pixels does not guarantee invisible seams or smooth gradients.
- Derived maps use periodic filtering and derivatives.
- Normal strength depends on resolution.
- RGB is assumed sRGB; ICC profiles are not transformed.
- Maps are 8-bit PNGs, with output sizes from 16 to 2048 pixels.
- Inputs are limited to 64 megapixels; transparent inputs must be flattened.
- Output directories must be new; failed exports can leave partial files.

## Tests

Development runs reported 31 FrameSteady, 22 MediaFoundry, and 10 TextureSmith
tests passing. This does not guarantee every platform, input, or dependency
version, or establish commercial parity.

Native installation:

    python -m pip install -e ".[dev]"
    python -m pytest -q

Docker launchers:

    ./run_framesteady.sh --test
    ./run_mediafoundry.sh --test
    ./run_texturesmith.sh --test

## Feedback

Include your command, operating system, installation method, and error output.
A small sample you have permission to share is helpful.
Do not post secrets, private media, or confidential metadata.

## License

Original code: MIT; see LICENSE.
Dependencies retain their own licenses; see THIRD_PARTY_NOTICES.md.

No affiliation with proprietary software vendors is implied.
No graphical interface, AI models, or required AI coding agent are included.
