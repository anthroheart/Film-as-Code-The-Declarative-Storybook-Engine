# Third-party notices

MIT covers original project code, not every dependency or built container.

Main dependencies:
- Python: Python Software Foundation license and associated notices.
- NumPy and SciPy: BSD-style licenses plus bundled third-party notices.
- Pillow: consult the installed distribution's license and codec-library notices.
- FFmpeg/ffprobe: LGPL or GPL obligations depend on build configuration and
  linked libraries. Debian builds commonly enable GPL components.
- libx264 and other codecs: separate licenses and potentially patent obligations.
- Development/build tools: pytest, setuptools, pip, wheel, and container OS
  packages retain their own licenses.

This release contains source code, not bundled third-party executables.
The Dockerfile downloads third-party software. Redistributing a built image
is different from sharing this source Dockerfile.

Review exact dependency notices before distributing binary bundles or images.
This file is an inventory, not a complete dependency license audit.
