"""FrameSteady: global exposure correction for sRGB PNG sequences."""

import argparse
import csv
import json
import pathlib
import sys

import numpy as np
from PIL import Image

from . import validation


def analyze_sequence(paths):
    measurements = []
    for path in paths:
        with Image.open(path) as image:
            linear = validation.srgb_to_linear(np.array(image))
        measurements.append(validation.robust_luminance(linear))
    return measurements


def linear_to_srgb(img_linear):
    arr = np.clip(img_linear, 0, 1)
    srgb = np.where(
        arr <= 0.0031308,
        12.92 * arr,
        1.055 * np.power(arr, 1 / 2.4) - 0.055,
    )
    return np.floor(np.clip(srgb, 0, 1) * 255 + 0.5).astype(np.uint8)


def correct_exposure_linear(
    img_linear, target_lum, current_lum,
    min_gain=0.25, max_gain=4.0, strength=1.0,
):
    values = [target_lum, current_lum, min_gain, max_gain, strength]
    if not np.all(np.isfinite(values)):
        raise ValueError("Exposure settings must be finite.")
    if target_lum < 0 or current_lum < 0:
        raise ValueError("Luminance cannot be negative.")
    if not 0 < min_gain <= 1 <= max_gain:
        raise ValueError("Gain limits must include 1.")
    if not 0 <= strength <= 1:
        raise ValueError("Strength must be between 0 and 1.")

    if current_lum <= 1e-6 or strength == 0:
        gain = 1.0
    elif target_lum <= 0:
        gain = min_gain
    else:
        stops = strength * np.log2(target_lum / current_lum)
        stops = np.clip(stops, np.log2(min_gain), np.log2(max_gain))
        gain = float(2.0 ** stops)

    output = np.clip(img_linear * gain, 0, 1).astype(np.float32)
    return output, float(gain)


def exposure_targets(luminances, window=15, cuts=()):
    """
    Smooth log luminance separately within each shot.

    window: odd number of frames.
    cuts: zero-based indices where a NEW shot starts.
    Invalid/black measurements are interpolated only for estimating targets.
    Actual black frames remain uncorrected.
    """
    values = np.asarray(luminances, dtype=np.float64)
    if values.ndim != 1 or len(values) == 0:
        raise ValueError("Expected a nonempty luminance sequence.")
    if not np.all(np.isfinite(values)) or np.any(values < 0):
        raise ValueError("Luminance values must be finite and nonnegative.")
    if not isinstance(window, (int, np.integer)):
        raise ValueError("Window must be an odd integer.")
    if window < 1 or window > 10001 or window % 2 == 0:
        raise ValueError("Window must be odd and between 1 and 10001.")

    cuts = list(cuts)
    if any(not isinstance(c, (int, np.integer)) for c in cuts):
        raise ValueError("Shot boundaries must be integer frame indices.")
    if cuts != sorted(set(cuts)):
        raise ValueError("Shot boundaries must be sorted and unique.")
    if any(c <= 0 or c >= len(values) for c in cuts):
        raise ValueError("Shot boundaries must fall inside the sequence.")

    boundaries = [0, *cuts, len(values)]
    targets = np.zeros_like(values)

    for start, end in zip(boundaries[:-1], boundaries[1:]):
        shot = values[start:end]
        valid = shot > 1e-6
        if not np.any(valid):
            continue

        indices = np.arange(len(shot))
        logs = np.interp(
            indices,
            indices[valid],
            np.log(shot[valid]),
        )

        # Do not allocate a huge padded array for very short shots.
        width = min(window, 2 * len(shot) - 1)
        radius = width // 2
        padded = np.pad(logs, (radius, radius), mode="edge")
        smooth = np.convolve(
            padded, np.ones(width, dtype=np.float64) / width,
            mode="valid",
        )
        targets[start:end] = np.exp(smooth)

    return targets


def _write_png_exclusive(path, pixels):
    # Refuse overwriting even if the path appeared after preflight.
    stream = path.open("xb")
    try:
        with stream:
            Image.fromarray(pixels).save(stream, format="PNG")
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def save_corrected_sequence(
    paths, out_dir, target="median", *,
    window=15, strength=1.0, max_stops=2.0, cuts=(),
):
    """
    Save corrected PNGs plus exposure.csv and report.json.

    Legacy API default: constant median target.
    target="smooth": temporally smoothed log-exposure target.

    Returns (records, scalar target or per-frame target array).
    Existing outputs are refused. Completed files may remain after a failure.
    """
    if target not in {"median", "mean", "smooth"}:
        raise ValueError("Target must be median, mean, or smooth.")
    if not np.isfinite(strength) or not 0 <= strength <= 1:
        raise ValueError("Strength must be between 0 and 1.")
    if not np.isfinite(max_stops) or not 0 <= max_stops <= 16:
        raise ValueError("Maximum stops must be between 0 and 16.")

    cuts = list(cuts)
    if cuts and target != "smooth":
        raise ValueError("Shot boundaries require --target smooth.")

    paths, _ = validation.validate_png_sequence(paths)
    out_dir = pathlib.Path(out_dir)
    outputs = [out_dir / f"{p.stem}_steady.png" for p in paths]
    destinations = outputs + [
        out_dir / "exposure.csv", out_dir / "report.json"
    ]

    resolved = [p.resolve() for p in destinations]
    if len(set(resolved)) != len(resolved):
        raise ValueError("Input filenames would produce duplicate outputs.")
    inputs = {p.resolve() for p in paths}
    if any(p in inputs for p in resolved):
        raise ValueError("An output would overwrite an input.")

    for path in destinations:
        if path.exists() or path.is_symlink():
            raise FileExistsError(
                f"Output already exists; choose a new folder: {path}"
            )

    luminances = np.asarray(analyze_sequence(paths), dtype=np.float64)
    if target == "smooth":
        targets = exposure_targets(luminances, window, cuts)
        returned_target = targets
    else:
        reference = float(
            np.median(luminances) if target == "median"
            else np.mean(luminances)
        )
        targets = np.full(len(paths), reference)
        returned_target = reference

    out_dir.mkdir(parents=True, exist_ok=True)
    records = []
    min_gain, max_gain = 2.0 ** -max_stops, 2.0 ** max_stops

    for index, (path, output, lum, wanted) in enumerate(
        zip(paths, outputs, luminances, targets)
    ):
        with Image.open(path) as image:
            linear = validation.srgb_to_linear(np.array(image))

        corrected, gain = correct_exposure_linear(
            linear, float(wanted), float(lum),
            min_gain, max_gain, strength,
        )
        pixels = linear_to_srgb(corrected)
        _write_png_exclusive(output, pixels)

        measurable = lum > 1e-6
        if not measurable or strength == 0:
            requested_stops = 0.0
            limited = False
        elif wanted <= 0:
            requested_stops = None
            limited = True
        else:
            requested_stops = float(strength * np.log2(wanted / lum))
            limited = abs(requested_stops) > max_stops + 1e-12

        records.append({
            "frame": index,
            "input": str(path),
            "output": str(output),
            "pre": float(lum),
            "target": float(wanted),
            "gain": gain,
            "gain_limited": bool(limited),
            "unmeasurable": bool(not measurable),
            "requested_stops": requested_stops,
            "post": validation.robust_luminance(
                validation.srgb_to_linear(pixels)
            ),
        })

    with (out_dir / "exposure.csv").open(
        "x", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)

    summary = {
        "tool": "FrameSteady",
        "settings": {
            "target": target,
            "window": window,
            "strength": strength,
            "max_stops": max_stops,
            "cuts": cuts,
            "color_assumption": "8-bit RGB interpreted as sRGB",
        },
        "frame_count": len(records),
        "gain_limited_frames": sum(r["gain_limited"] for r in records),
        "unmeasurable_frames": sum(r["unmeasurable"] for r in records),
        "limitations": [
            "Global exposure correction only.",
            "Changing scene content can influence exposure estimates.",
            "Slow lighting changes can be affected, especially at shot edges.",
            "Clipped detail cannot be recovered.",
            "Completed outputs may remain after an interrupted run.",
        ],
        "frames": records,
    }
    with (out_dir / "report.json").open("x", encoding="utf-8") as stream:
        json.dump(summary, stream, indent=2, allow_nan=False)
        stream.write("\n")

    return records, returned_target


def main():
    parser = argparse.ArgumentParser(
        description="FrameSteady: global exposure deflickering for PNG sequences"
    )
    parser.add_argument(
        "input", nargs="+",
        help="PNG paths, or one directory containing PNGs",
    )
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--target", choices=["smooth", "median", "mean"], default="smooth"
    )
    parser.add_argument("--window", type=int, default=15)
    parser.add_argument("--strength", type=float, default=1.0)
    parser.add_argument("--max-stops", type=float, default=2.0)
    parser.add_argument(
        "--cuts", default="",
        help="Comma-separated zero-based new-shot indices, e.g. 100,250",
    )
    args = parser.parse_args()

    try:
        paths = [pathlib.Path(p) for p in args.input]
        if len(paths) == 1 and paths[0].is_dir():
            paths = [
                p for p in paths[0].iterdir()
                if p.is_file() and p.suffix.lower() == ".png"
            ]
        cuts = (
            [int(value.strip()) for value in args.cuts.split(",")]
            if args.cuts.strip() else []
        )
        records, _ = save_corrected_sequence(
            paths, args.out, target=args.target,
            window=args.window, strength=args.strength,
            max_stops=args.max_stops, cuts=cuts,
        )
        print(f"Saved {len(records)} corrected frames to {args.out}")
        print("Reports: exposure.csv and report.json")
        print(
            f"Gain-limited frames: "
            f"{sum(r['gain_limited'] for r in records)}"
        )
    except Exception as exc:
        print(f"FrameSteady error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
