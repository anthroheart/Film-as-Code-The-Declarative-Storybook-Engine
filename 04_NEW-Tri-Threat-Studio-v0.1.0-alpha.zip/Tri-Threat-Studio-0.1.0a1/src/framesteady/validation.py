import pathlib
from PIL import Image
import re

def natural_key(string):
    # Natural/alphanumeric sorting
    return [int(text) if text.isdigit() else text.lower()
            for text in re.split(r'(\d+)', str(string))]

def validate_png_sequence(paths):
    paths = [pathlib.Path(p) for p in paths]
    if not paths:
        raise ValueError('No input files provided.')
    # Natural sort
    paths = sorted(paths, key=natural_key)
    size = None
    valid_paths = []
    for path in paths:
        if not path.is_file():
            raise ValueError(f'File not found: {path}')
        try:
            with Image.open(path) as im:
                if im.format != 'PNG':
                    raise ValueError(f'Non-PNG file: {path}')
                if im.mode != 'RGB':
                    raise ValueError(f'Not 8-bit sRGB PNG (mode={im.mode}): {path}')
                if size is None:
                    size = im.size
                elif im.size != size:
                    raise ValueError(f'Image sizes do not match: {path} has {im.size}, expected {size}')
                im.load()  # Decode now, catching truncated image data.
                valid_paths.append(path)
        except Exception as e:
            raise ValueError(f'Error reading {path}: {e}')
    return valid_paths, size
import numpy as np

def srgb_to_linear(img):
    """
    Convert an 8-bit sRGB uint8 NumPy RGB array (shape HxWx3) to linear float32 (0..1).
    """
    arr = img.astype(np.float32) / 255.0
    # Vectorized sRGB -> linear
    lin = np.where(
        arr <= 0.04045,
        arr / 12.92,
        ((arr + 0.055) / 1.055) ** 2.4
    )
    return lin

def robust_luminance(img_linear, black_thresh=0.01, white_thresh=0.99):
    """
    Estimate mean luminance of linear RGB float32 image, excluding nearly-black or -white pixels.
    Uses Rec.709 luma weights.
    """
    assert img_linear.dtype == np.float32 and img_linear.shape[2] == 3
    coeffs = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)  # Rec.709
    lum = np.tensordot(img_linear, coeffs, axes=([-1], [0]))
    # Mask for robust mean (exclude near black/white)
    mask = (lum > black_thresh) & (lum < white_thresh)
    if np.any(mask):
        return float(np.mean(lum[mask]))
    else:
        return float(np.mean(lum))  # fallback: all black/white
