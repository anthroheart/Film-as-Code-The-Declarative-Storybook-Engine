import argparse
import pathlib
import sys

from . import convert, metadata
from .pipeline import PRESETS, process_file

MEDIA_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff",
    ".mp4", ".mov", ".avi", ".mkv", ".webm",
    ".wav", ".mp3", ".flac", ".ogg",
}


def scan_media_files(directory):
    path = pathlib.Path(directory)
    if not path.is_dir():
        raise ValueError(f"{directory} is not a directory")
    return sorted(
        str(f) for f in path.iterdir()
        if f.is_file() and f.suffix.lower() in MEDIA_EXTENSIONS
    )


def main():
    parser = argparse.ArgumentParser(
        description="MediaFoundry: local media processing"
    )
    commands = parser.add_subparsers(dest="command", required=True)

    scan = commands.add_parser("scan", help="Scan media files")
    scan.add_argument(
        "directory", nargs="?", default=".",
        help="Directory to scan for media files",
    )
    scan.add_argument("--meta", action="store_true")

    image = commands.add_parser("convert", help="Copy/convert one image")
    image.add_argument("input")
    image.add_argument("--out", required=True)

    commands.add_parser("presets", help="List video/audio presets")

    process = commands.add_parser("process", help="Process video or audio")
    process.add_argument("input")
    process.add_argument("--out", required=True)
    process.add_argument("--preset", choices=list(PRESETS), default="proxy")
    process.add_argument(
        "--timeout", type=int, default=1800,
        help="Seconds allowed per encode/decode operation",
    )

    args = parser.parse_args()

    try:
        if args.command == "scan":
            files = scan_media_files(args.directory)
            if not files:
                print(f"No media files found in {args.directory}")
            else:
                print("Found media files:")
                for name in files:
                    details = metadata.get_media_metadata(name) if args.meta else None
                    suffix = (
                        "  [" + ", ".join(
                            f"{k}={details[k]!r}" for k in sorted(details)
                        ) + "]"
                        if details else ""
                    )
                    print(name + suffix)

        elif args.command == "convert":
            convert.convert_image_lossless(args.input, args.out)
            print(f"Image copied/converted: {args.input} -> {args.out}")
            print("Only same-extension byte copying is guaranteed lossless.")

        elif args.command == "presets":
            for name, settings in PRESETS.items():
                print(f"{name}: {settings['description']}")

        elif args.command == "process":
            print("Processing and verifying locally...", flush=True)
            report = process_file(
                args.input, args.out, args.preset, args.timeout
            )
            print(f"Saved: {args.out}")
            print(f"Report: {args.out}.json")
            print(f"Log: {args.out}.log")
            for warning in report["warnings"]:
                print(f"Note: {warning}")

    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
