"""Local FFmpeg processing with verification and no-clobber publication."""

import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

PRESETS = {
    "proxy": {
        "extension": ".mp4",
        "description": "H.264/AAC, maximum 1280x720, CRF 23",
    },
    "delivery": {
        "extension": ".mp4",
        "description": "H.264/AAC, original-sized SDR video, CRF 18",
    },
    "audio": {
        "extension": ".wav",
        "description": "First audio stream as uncompressed 24-bit PCM WAV",
    },
}


def probe(path):
    result = subprocess.run(
        [
            "ffprobe", "-v", "error",
            "-protocol_whitelist", "file,pipe",
            "-show_streams", "-show_format", "-of", "json",
            str(path),
        ],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode:
        raise ValueError(
            "Cannot read media: " + result.stderr.strip()[-1500:]
        )
    return json.loads(result.stdout)


def publish(source, destination):
    """Atomically publish one file without replacing an existing destination."""
    # Staging files reside on the same filesystem as the destination.
    os.link(source, destination)
    source.unlink()


def run_ffmpeg(command, log, timeout):
    result = subprocess.run(
        command, stdout=log, stderr=log,
        timeout=timeout, check=False,
    )
    if result.returncode:
        raise RuntimeError(
            f"FFmpeg exited with code {result.returncode}; see the log."
        )


def duration(info):
    try:
        value = float(info.get("duration"))
        return value if math.isfinite(value) and value > 0 else None
    except (TypeError, ValueError):
        return None


def encoder_check(names):
    result = subprocess.run(
        ["ffmpeg", "-hide_banner", "-encoders"],
        capture_output=True, text=True, timeout=30, check=True,
    )
    available = {
        parts[1]
        for line in result.stdout.splitlines()
        if len(parts := line.split()) >= 2
    }
    missing = set(names) - available
    if missing:
        raise ValueError("Missing FFmpeg encoders: " + ", ".join(sorted(missing)))


def process_file(source, output, preset="proxy", timeout=1800):
    if preset not in PRESETS:
        raise ValueError("Unknown preset.")
    if not isinstance(timeout, int) or timeout < 1:
        raise ValueError("Timeout must be a positive number of seconds.")

    source = Path(source).resolve(strict=True)
    output = Path(output).absolute()
    if not source.is_file():
        raise ValueError("Input must be a regular file.")
    if output.suffix.lower() != PRESETS[preset]["extension"]:
        raise ValueError(
            f"{preset} requires a {PRESETS[preset]['extension']} output."
        )

    report_path = output.with_name(output.name + ".json")
    log_path = output.with_name(output.name + ".log")
    destinations = [output, report_path, log_path]

    for path in destinations:
        if path.resolve() == source:
            raise ValueError("Output artifacts must not overwrite the input.")
        if path.exists() or path.is_symlink():
            raise FileExistsError(f"Already exists: {path}")

    output.parent.mkdir(parents=True, exist_ok=True)

    record = {
        "success": False,
        "input": str(source),
        "output": str(output),
        "preset": preset,
        "warnings": [],
        "verification": {},
    }
    failure = None

    with tempfile.TemporaryDirectory(
        dir=output.parent, prefix=".mediafoundry-"
    ) as directory:
        stage = Path(directory)
        media = stage / ("encoded" + output.suffix.lower())
        staged_log = stage / "processing.log"
        staged_report = stage / "report.json"

        with staged_log.open("w", encoding="utf-8") as log:
            try:
                info = probe(source)
                streams = info.get("streams", [])
                videos = [
                    s for s in streams
                    if s.get("codec_type") == "video"
                    and not s.get("disposition", {}).get("attached_pic", 0)
                ]
                audios = [
                    s for s in streams if s.get("codec_type") == "audio"
                ]

                video = videos[0] if videos else None
                audio = audios[0] if audios else None

                if preset == "audio":
                    if audio is None:
                        raise ValueError("Input has no audio stream.")
                    chosen = [audio]
                    encoder_check(["pcm_s24le"])
                else:
                    if video is None:
                        raise ValueError("Input has no ordinary video stream.")
                    transfer = video.get("color_transfer", "")
                    if transfer in {"smpte2084", "arib-std-b67"}:
                        raise ValueError(
                            "HDR input is not supported by these SDR presets."
                        )
                    sar = video.get("sample_aspect_ratio", "1:1")
                    if sar not in {"1:1", "0:1", "N/A", None}:
                        raise ValueError(
                            "Non-square-pixel input is not supported yet."
                        )
                    if min(video.get("width", 0), video.get("height", 0)) < 2:
                        raise ValueError("Video dimensions must be at least 2x2.")

                    chosen = [video] + ([audio] if audio else [])
                    encoder_check(["libx264"] + (["aac"] if audio else []))
                    record["warnings"].append(
                        "SDR workflow: no HDR tone mapping or managed "
                        "color-space conversion is performed."
                    )
                    if not transfer or transfer == "unknown":
                        record["warnings"].append(
                            "Input transfer characteristics are unspecified; "
                            "the source is assumed to be suitable SDR video."
                        )

                selected = [s["index"] for s in chosen]
                ignored = [
                    {"index": s["index"], "type": s.get("codec_type")}
                    for s in streams if s["index"] not in selected
                ]
                record["selected_stream_indices"] = selected
                record["discarded_streams"] = ignored
                if ignored:
                    record["warnings"].append(
                        f"Discarding {len(ignored)} unselected stream(s); "
                        "see discarded_streams."
                    )
                record["warnings"].append(
                    "Source metadata and chapters are not copied."
                )

                known_durations = [duration(s) for s in chosen]
                if all(d is not None for d in known_durations):
                    expected_duration = max(known_durations)
                else:
                    expected_duration = duration(info.get("format", {}))

                command = [
                    "ffmpeg", "-nostdin", "-hide_banner",
                    "-loglevel", "warning", "-y",
                    "-filter_threads", "1",
                    "-protocol_whitelist", "file,pipe",
                    "-i", str(source),
                ]
                for index in selected:
                    command += ["-map", f"0:{index}"]

                command += ["-map_metadata", "-1", "-map_chapters", "-1"]

                if preset == "audio":
                    command += ["-vn", "-c:a", "pcm_s24le"]
                else:
                    if preset == "proxy":
                        video_filter = (
                            "scale=w='min(1280,iw)':h='min(720,ih)':"
                            "force_original_aspect_ratio=decrease:"
                            "force_divisible_by=2"
                        )
                    else:
                        # Pad odd dimensions by at most one pixel.
                        video_filter = "pad=ceil(iw/2)*2:ceil(ih/2)*2"

                    command += [
                        "-vf", video_filter,
                        "-c:v", "libx264",
                        "-preset", "veryfast",
                        "-crf", "23" if preset == "proxy" else "18",
                        "-pix_fmt", "yuv420p",
                        "-threads", "2",
                        "-movflags", "+faststart",
                    ]
                    if audio:
                        command += ["-c:a", "aac", "-b:a", "192k"]

                command.append(str(media))
                record["command"] = command
                version = subprocess.run(
                    ["ffmpeg", "-version"],
                    capture_output=True, text=True, timeout=10, check=True,
                )
                record["ffmpeg_version"] = version.stdout.splitlines()[0]

                run_ffmpeg(command, log, timeout)
                encoded = probe(media)
                output_streams = encoded.get("streams", [])
                types = [s.get("codec_type") for s in output_streams]
                expected_types = [s["codec_type"] for s in chosen]

                if sorted(types) != sorted(expected_types):
                    raise RuntimeError("Output stream verification failed.")

                actual_duration = duration(encoded.get("format", {}))
                if actual_duration is None:
                    raise RuntimeError("Output has no valid positive duration.")

                if expected_duration is not None:
                    tolerance = max(0.5, expected_duration * 0.02)
                    if abs(actual_duration - expected_duration) > tolerance:
                        raise RuntimeError(
                            "Output duration differs unexpectedly from input."
                        )
                else:
                    record["warnings"].append(
                        "Input duration unavailable; duration matching skipped."
                    )

                # Decode the complete output to catch errors beyond its header.
                run_ffmpeg(
                    [
                        "ffmpeg", "-nostdin", "-hide_banner",
                        "-v", "error", "-xerror", "-threads", "2",
                        "-protocol_whitelist", "file,pipe",
                        "-i", str(media), "-map", "0",
                        "-f", "null", "-",
                    ],
                    log, timeout,
                )

                record["verification"] = {
                    "stream_types": types,
                    "output_duration_seconds": actual_duration,
                    "expected_duration_seconds": expected_duration,
                    "full_decode_passed": True,
                }
                record["success"] = True

            except Exception as exc:
                failure = exc
                record["error"] = f"{type(exc).__name__}: {exc}"
                log.write("\n" + record["error"] + "\n")

        staged_report.write_text(
            json.dumps(record, indent=2, allow_nan=False) + "\n",
            encoding="utf-8",
        )

        # Each file is individually published without replacement.
        # The three artifacts are not a single atomic transaction.
        publish(staged_log, log_path)
        publish(staged_report, report_path)

        if failure is not None:
            raise RuntimeError(
                f"Processing failed: {failure}\n"
                f"Details: {report_path}\nLog: {log_path}"
            ) from failure

        publish(media, output)

    return record
