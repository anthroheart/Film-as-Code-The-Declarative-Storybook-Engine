"""Image copying/conversion. Only same-extension copying is byte-lossless."""

from pathlib import Path
import shutil
import tempfile

from PIL import Image

from .pipeline import publish


def convert_image_lossless(input_path, output_path):
    source = Path(input_path).resolve(strict=True)
    output = Path(output_path).absolute()

    if output.resolve() == source:
        raise ValueError("Output path must differ from input.")
    if output.exists() or output.is_symlink():
        raise FileExistsError(f"Output already exists: {output}")

    allowed = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff"}
    if source.suffix.lower() not in allowed:
        raise ValueError(f"Unsupported image extension: {source.suffix}")
    if output.suffix.lower() not in allowed:
        raise ValueError(f"Unsupported output extension: {output.suffix}")

    with Image.open(source) as image:
        image.verify()

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        dir=output.parent, prefix=".mediafoundry-image-"
    ) as directory:
        staged = Path(directory) / ("image" + output.suffix.lower())
        if source.suffix.lower() == output.suffix.lower():
            shutil.copyfile(source, staged)
        else:
            with Image.open(source) as image:
                if getattr(image, "n_frames", 1) != 1:
                    raise ValueError(
                        "Multi-frame image format conversion is unsupported."
                    )
                image.save(staged)
        publish(staged, output)

    return True
