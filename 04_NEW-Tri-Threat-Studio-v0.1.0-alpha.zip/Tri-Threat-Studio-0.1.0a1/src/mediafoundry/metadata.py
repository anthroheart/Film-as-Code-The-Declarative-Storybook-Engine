import os
from pathlib import Path
from PIL import Image
import subprocess

def get_image_metadata(path):
    """Return dict with width, height for recognized image files, else None"""
    try:
        with Image.open(path) as img:
            return {
                'type': 'image',
                'width': img.width,
                'height': img.height,
                'format': img.format,
            }
    except Exception:
        return None

def get_video_metadata(path):
    """Use ffmpeg to get basic video info (duration, width, height). Returns dict or None."""
    try:
        # Call ffprobe as an external process, parse minimal JSON for width/height/duration
        cmd = [
            'ffprobe', '-v', 'error', '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height,duration',
            '-of', 'default=noprint_wrappers=1:nokey=0',
            str(path)
        ]
        out = subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True, timeout=30)
        result = {}
        for line in out.strip().split('\n'):
            if '=' in line:
                key, val = line.strip().split('=', 1)
                try:
                    val = float(val) if '.' in val else int(val)
                except Exception:
                    pass
                result[key] = val
        if 'width' in result and 'height' in result:
            return {
                'type': 'video',
                'width': result['width'],
                'height': result['height'],
                'duration': result.get('duration', None)
            }
        return None
    except Exception:
        return None

def get_media_metadata(path):
    ext = Path(path).suffix.lower()
    if ext in {'.png', '.jpg', '.jpeg', '.bmp', '.gif', '.tif', '.tiff'}:
        return get_image_metadata(path)
    elif ext in {'.mp4', '.mov', '.avi', '.mkv', '.webm'}:
        return get_video_metadata(path)
    return None
