# SPDX-License-Identifier: MIT
"""Artist-controlled approximations, not physical material reconstruction."""

import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps
from scipy.ndimage import gaussian_filter, uniform_filter


def tile_edges(image, blend=0.15):
    """
    Blend opposing borders, matching their pixel values exactly.

    This baseline can produce ghosting and repetition. Matching border
    values does not guarantee matching gradients or invisible seams.
    """
    if not np.isfinite(blend) or not 0 < blend <= 0.5:
        raise ValueError("Blend must be greater than 0 and at most 0.5.")
    out = np.asarray(image, dtype=np.float32).copy()
    if out.ndim != 3 or out.shape[2] != 3:
        raise ValueError("Expected an RGB image.")
    height, width = out.shape[:2]
    if min(height, width) < 4:
        raise ValueError("Image must be at least 4x4.")

    count_x = max(1, min(width // 2, round(width * blend)))
    for offset in range(count_x):
        weight = 0.5 * (1 - offset / count_x)
        left = out[:, offset].copy()
        right = out[:, -1-offset].copy()
        out[:, offset] = left * (1 - weight) + right * weight
        out[:, -1-offset] = right * (1 - weight) + left * weight

    count_y = max(1, min(height // 2, round(height * blend)))
    for offset in range(count_y):
        weight = 0.5 * (1 - offset / count_y)
        top = out[offset].copy()
        bottom = out[-1-offset].copy()
        out[offset] = top * (1 - weight) + bottom * weight
        out[-1-offset] = bottom * (1 - weight) + top * weight

    return np.clip(out, 0, 1)


def linear_luminance(rgb):
    rgb = np.asarray(rgb, dtype=np.float32)
    linear = np.where(
        rgb <= 0.04045,
        rgb / 12.92,
        ((rgb + 0.055) / 1.055) ** 2.4,
    )
    return (
        linear[..., 0] * 0.2126
        + linear[..., 1] * 0.7152
        + linear[..., 2] * 0.0722
    )


def height_map(rgb, contrast=1.0, blur=1.0, invert=False):
    if not np.isfinite(contrast) or not 0 <= contrast <= 10:
        raise ValueError("Height contrast must be between 0 and 10.")
    if not np.isfinite(blur) or not 0 <= blur <= 20:
        raise ValueError("Height blur must be between 0 and 20 pixels.")

    values = linear_luminance(rgb)
    low, high = np.percentile(values, [2, 98])

    if high - low < 1e-8:
        height = np.full(values.shape, 0.5, dtype=np.float32)
    else:
        height = np.clip((values - low) / (high - low), 0, 1)

    if blur > 0:
        height = gaussian_filter(height, sigma=blur, mode="wrap")

    height = np.clip((height - 0.5) * contrast + 0.5, 0, 1)
    if invert:
        height = 1 - height
    return height.astype(np.float32)


def normal_map(height, strength=4.0, convention="opengl"):
    """
    Periodic central differences, normalized before encoding.

    Strength is relative to changes per pixel, not a physical distance.
    OpenGL convention uses tangent +Y upward while image rows run downward.
    DirectX output flips the green channel.
    """
    if not np.isfinite(strength) or not 0 <= strength <= 100:
        raise ValueError("Normal strength must be between 0 and 100.")
    if convention not in {"opengl", "directx"}:
        raise ValueError("Normal convention must be opengl or directx.")

    height = np.asarray(height, dtype=np.float32)
    if height.ndim != 2 or not np.all(np.isfinite(height)):
        raise ValueError("Expected a finite 2D height map.")

    dx = (np.roll(height, -1, axis=1) - np.roll(height, 1, axis=1)) * 0.5
    dy = (np.roll(height, -1, axis=0) - np.roll(height, 1, axis=0)) * 0.5

    normals = np.stack(
        [-dx * strength, dy * strength, np.ones_like(height)],
        axis=-1,
    )
    if convention == "directx":
        normals[..., 1] *= -1

    normals /= np.linalg.norm(normals, axis=-1, keepdims=True)
    return (normals * 0.5 + 0.5).astype(np.float32)


def roughness_map(rgb, base=0.6, detail=0.3):
    """
    Heuristic: local image variation modulates roughness.

    Bright means rougher. This is not measured physical roughness.
    """
    if not np.isfinite(base) or not 0 <= base <= 1:
        raise ValueError("Roughness base must be between 0 and 1.")
    if not np.isfinite(detail) or not 0 <= detail <= 1:
        raise ValueError("Roughness detail must be between 0 and 1.")

    luminance = linear_luminance(rgb)
    mean = uniform_filter(luminance, size=5, mode="wrap")
    square_mean = uniform_filter(luminance ** 2, size=5, mode="wrap")
    deviation = np.sqrt(np.maximum(square_mean - mean ** 2, 0))

    scale = float(np.percentile(deviation, 95))
    variation = np.clip(deviation / scale, 0, 1) if scale > 1e-8 else deviation
    return np.clip(base + detail * variation, 0, 1).astype(np.float32)


def as_uint8(values):
    return np.floor(np.clip(values, 0, 1) * 255 + 0.5).astype(np.uint8)


def demo_image(size):
    """A deterministic procedural surface, with intentionally mismatched edges."""
    rng = np.random.default_rng(17)
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    x /= size
    y /= size
    noise = rng.normal(0, 0.04, (size, size))
    pattern = (
        0.5
        + 0.12 * np.sin(x * 31 + np.sin(y * 11) * 2)
        + 0.08 * np.cos(y * 23)
        + 0.12 * x
        + noise
    )
    rgb = np.stack(
        [pattern * 1.10, pattern * 0.91, pattern * 0.72], axis=-1
    )
    return Image.fromarray(as_uint8(rgb))


def prepare_image(source, size):
    if source is None:
        image = demo_image(size)
    else:
        with Image.open(source) as original:
            if original.width * original.height > 64_000_000:
                raise ValueError("Input exceeds the 64-megapixel limit.")
            image = ImageOps.exif_transpose(original)
            if image.mode in {"RGBA", "LA"} or "transparency" in image.info:
                alpha = image.convert("RGBA").getchannel("A")
                if alpha.getextrema()[0] < 255:
                    raise ValueError(
                        "Flatten transparent pixels onto a background first."
                    )
            image = image.convert("RGB")

    # Center crop rather than stretching the image into a square.
    image = ImageOps.fit(
        image, (size, size), method=Image.Resampling.LANCZOS
    )
    return np.asarray(image, dtype=np.float32) / 255.0


def generate(
    source, output, *, size=512, blend=0.15,
    height_contrast=1.0, height_blur=1.0, invert_height=False,
    normal_strength=4.0, normal_convention="opengl",
    roughness_base=0.6, roughness_detail=0.3,
):
    if not isinstance(size, int) or not 16 <= size <= 2048:
        raise ValueError("Size must be between 16 and 2048 pixels.")

    output = Path(output)
    if output.exists() or output.is_symlink():
        raise FileExistsError("Choose a new output directory.")

    prepared = prepare_image(source, size)
    base = tile_edges(prepared, blend)
    height = height_map(base, height_contrast, height_blur, invert_height)
    normals = normal_map(height, normal_strength, normal_convention)
    roughness = roughness_map(base, roughness_base, roughness_detail)

    base_pixels = as_uint8(base)
    preview_tile = Image.fromarray(base_pixels)
    preview_tile.thumbnail((256, 256), Image.Resampling.LANCZOS)
    tile_pixels = np.asarray(preview_tile)
    preview = np.tile(tile_pixels, (3, 3, 1))

    report = {
        "tool": "TextureSmith",
        "source": str(source) if source is not None else "procedural demo",
        "settings": {
            "size": size,
            "edge_blend": blend,
            "height_contrast": height_contrast,
            "height_blur_pixels": height_blur,
            "invert_height": invert_height,
            "normal_strength": normal_strength,
            "normal_convention": normal_convention,
            "roughness_base": roughness_base,
            "roughness_detail": roughness_detail,
        },
        "basecolor_border_mismatch": {
            "left_right_max": float(np.max(np.abs(base[:, 0] - base[:, -1]))),
            "top_bottom_max": float(np.max(np.abs(base[0] - base[-1]))),
        },
        "import_settings": {
            "basecolor.png": "sRGB/color",
            "height.png": "Non-Color/data; approximate height",
            "normal.png": (
                f"Non-Color/data; tangent-space {normal_convention} normal map"
            ),
            "roughness.png": "Non-Color/data; white is rough",
        },
        "limitations": [
            "RGB input is assumed to be sRGB; ICC profiles are not transformed.",
            "Source is center-cropped to a square.",
            "Base color is a processed photograph, not measured albedo.",
            "Height and roughness are artistic approximations.",
            "Opposite-edge blending can cause ghosting and repetition.",
            "Matching border values does not guarantee matching gradients.",
            "Derived maps use periodic filtering and derivatives.",
            "Normal strength depends on image resolution.",
            "Maps are 8-bit PNGs.",
            "A failed or interrupted export may leave a partial output folder.",
        ],
    }

    # Exclusive directory creation protects existing exports.
    output.mkdir(parents=True, exist_ok=False)
    exports = {
        "source.png": as_uint8(prepared),
        "basecolor.png": base_pixels,
        "height.png": as_uint8(height),
        "normal.png": as_uint8(normals),
        "roughness.png": as_uint8(roughness),
        "tiled-preview.png": preview,
    }
    for name, pixels in exports.items():
        with (output / name).open("xb") as stream:
            Image.fromarray(pixels).save(stream, format="PNG")

    with (output / "settings.json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write("\n")

    return report
