# SPDX-License-Identifier: MIT
import argparse
import sys

from .core import generate


def main():
    parser = argparse.ArgumentParser(
        description="TextureSmith: tileable textures and approximate material maps"
    )
    parser.add_argument("input", nargs="?", help="Surface photograph")
    parser.add_argument("--demo", action="store_true", help="Use generated input")
    parser.add_argument("--out", required=True, help="New output directory")
    parser.add_argument("--size", type=int, default=512)
    parser.add_argument("--blend", type=float, default=0.15)
    parser.add_argument("--height-contrast", type=float, default=1.0)
    parser.add_argument("--height-blur", type=float, default=1.0)
    parser.add_argument("--invert-height", action="store_true")
    parser.add_argument("--normal-strength", type=float, default=4.0)
    parser.add_argument(
        "--normal-convention", choices=["opengl", "directx"], default="opengl"
    )
    parser.add_argument("--roughness-base", type=float, default=0.6)
    parser.add_argument("--roughness-detail", type=float, default=0.3)
    args = parser.parse_args()

    if args.demo == (args.input is not None):
        parser.error("Supply either an input image or --demo, not both.")

    try:
        generate(
            args.input, args.out,
            size=args.size, blend=args.blend,
            height_contrast=args.height_contrast,
            height_blur=args.height_blur,
            invert_height=args.invert_height,
            normal_strength=args.normal_strength,
            normal_convention=args.normal_convention,
            roughness_base=args.roughness_base,
            roughness_detail=args.roughness_detail,
        )
        print(f"Saved texture maps to: {args.out}")
        print("Open tiled-preview.png first.")
        print("Import settings and limitations: settings.json")
        print("Height and roughness are approximations, not measured materials.")
    except Exception as exc:
        print(f"TextureSmith error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
