# SPDX-License-Identifier: MIT
"""TextureSmith: deterministic texture and material-map generation."""
